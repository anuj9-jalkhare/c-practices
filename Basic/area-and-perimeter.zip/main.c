#include <stdio.h>

int main()
{
    int L;
    printf("ENTER LENGTH :");
    scanf("%d",&L);
    int B;
    printf("ENTER  BREADTH :");
    scanf("%d",&B);
    int a = L*B;
    int p = 2*(L+B);
    if(a>p){
        printf("area is greater then perimeter ");
    }else{     
        printf("area is not greater then perimeter ");
        
    }
    return 0;
}