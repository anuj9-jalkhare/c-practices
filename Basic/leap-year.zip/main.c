#include <stdio.h>
int main() {
	int n;
	printf("enter year :");
	scanf("%d",&n);
	if((n%100!=0)||(n%4==0&&n%400==0)){
		printf(" is a leap year");
	}
	else{
	    printf("is not a leap year");
	}
	return 0;
}
