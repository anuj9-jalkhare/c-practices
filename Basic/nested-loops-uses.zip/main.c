 #include <stdio.h>
 int main()
 {
    int a,b,c;
    printf("Enter ram age ->");
    scanf("%d",&a);
     printf("Enter shyam age ->");
    scanf("%d",&b);
     printf("Enter ajay age ->");
    scanf("%d",&c);
    if(a<b)//shyam out 
    {
        if(a<c)
        printf("%dram is youngest ",a);
        else
        
        printf("%d ajay is youngest ",c);
        
    }
     else {
         if(b<c)
         printf("%d shyam is younngest ",b);
         else
         printf("%d ajay is youngest ",c);
     }
    return 0; 
 }  