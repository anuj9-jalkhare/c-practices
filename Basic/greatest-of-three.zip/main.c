#include <stdio.h>
 int main()
 {
    int a,b,c;
    printf("enter 1st value : ");
    scanf("%d",&a);
     printf("enter 2nd value : ");
    scanf("%d",&b);
     printf("enter 3rd value : ");
    scanf("%d",&c);
    if(a>b && a>c){
        printf("%d 1st is greatest no. ",a);
    }
    if(b>a && b>c){
        printf("%d 2nd is greatest no. ",b);
    } 
    if(c>a && c>b){
        printf("%d 3rd is greatest no. ",c);
    }
    return 0; 
 }