#include <stdio.h>
int main()
{
    int n;
    printf("Enter a no. :");
    scanf("%d",&n);
    if(n%5==0||n%3==0){
        printf("The no. is divisible by 3 or 5 % ",n);
    }
    else{
        printf("The no. is not divisible by 3 or 5 bot");
    }
    return 0;
}