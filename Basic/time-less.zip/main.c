#include<stdio.h>
int main()
{ 
    int p ,q;
    printf("entre value of p and q");
    scanf("%d %d",&p,&q);
    printf("p=%d q=%d",p,q);
  return 0;
}